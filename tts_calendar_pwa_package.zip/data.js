
// Replace the [] with your full events array from your current app (window.__DATA__)
window.__DATA__ = [];
